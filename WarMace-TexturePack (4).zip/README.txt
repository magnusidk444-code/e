WarMace texture pack
====================
Textured: Butcher, War-Mace, Lightsaber, Chained Sword (animated on hit), Chicken Dagger,
Heavenly Helmet, Chorus Boots, Voltium Chestplate, Silent Chestplate, Etherium Pickaxe,
Golden Syrup, Hook-Spear, Forsaken Ominous Bottle, Spectro Bow (+ pull frames),
Veiro-Blade, Kitten Blade, Shiny Chicken, and the 9 Supreme Mace tiers.

Everything else (Concussive Leggings, Heart, Totem of Life, Homebound Charm, Golden Feather,
stones, tokens, relics) keeps its normal look until you add a texture.

Only the WarMace custom items use these textures - normal vanilla items are untouched,
because every model is selected by the custom_model_data id the plugin puts on each item.

Add a texture for another item (e.g. the Heart):
 1. Put heart.png (16x16) in assets/warmace/textures/item/
 2. Create assets/warmace/models/item/heart.json:
      {"parent":"minecraft:item/generated","textures":{"layer0":"warmace:item/heart"}}
    (use minecraft:item/handheld as the parent for tools and weapons)
 3. In assets/minecraft/items/<base item>.json (heart_of_the_sea.json for the Heart) add a case:
      {"when":"heart","model":{"type":"minecraft:model","model":"warmace:item/heart"}}
    If the base item has no file yet, copy another one and change the case and fallback.
    Ids and base items are in the plugin (e.g. totem_of_life = totem_of_undying).
